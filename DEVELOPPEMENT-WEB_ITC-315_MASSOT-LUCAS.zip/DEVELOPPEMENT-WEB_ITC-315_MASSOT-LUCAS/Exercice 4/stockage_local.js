function initialize() { 
    var bSupportsLocal = (('localStorage' in window) && window['localStorage'] !== null);
    /*boolean pour savoir si l'API est supporté, si il ne l'est pas on affiche le message suivant au client*/
    if (!bSupportsLocal) {
        document.getElementById('infoform').innerHTML = "<p>Désolé, ce navigateur ne supporte pas l’API Web Storage du W3C.</p>";
        return;
    }

    /*si il y a des variables présente dans le stockage local alors on remplis le formulaire avec*/
    if (window.localStorage.length != 0) {
        document.getElementById('firstName').value = window.localStorage.getItem('firstName');
        document.getElementById('lastName').value = window.localStorage.getItem('lastName');
        document.getElementById('postCode').value = window.localStorage.getItem('postCode');
    }
}

/*Stockage des données dans le stockage du navigateur*/
function storeLocalContent(fName, lName, pCode) {
    window.localStorage.setItem('firstName', fName);
    window.localStorage.setItem('lastName', lName);
    window.localStorage.setItem('postCode', pCode);
}

/*permet de supprimer les données qui sont dans le stockage du navigateur*/
function clearLocalContent(){
    localStorage.clear();
}

window.onload = initialize;